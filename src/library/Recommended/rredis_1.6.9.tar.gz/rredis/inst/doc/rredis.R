### R code from vignette source 'rredis.Rnw'

